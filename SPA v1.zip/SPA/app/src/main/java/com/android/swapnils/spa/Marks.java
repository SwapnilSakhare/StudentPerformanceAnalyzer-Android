package com.android.swapnils.spa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Marks extends AppCompatActivity {
    Button button;
    String ten_th,elv_th,twe_th,fy,sy,ty;
    EditText etten,etelv,ettwe,etfy,etsy,etty;
    TextView stud_marks,tv1,tv2,tv3,tv4,tv5,tv6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marks);

        etten=(EditText)findViewById(R.id.tenth);
        etelv=(EditText)findViewById(R.id.elventh);
        ettwe=(EditText)findViewById(R.id.twelveth);
        etfy=(EditText)findViewById(R.id.fy);
        etsy=(EditText)findViewById(R.id.sy);
        etty=(EditText)findViewById(R.id.tyid);

        ten_th = etten.getText().toString().trim();
        elv_th=etelv.getText().toString().trim();
        twe_th=ettwe.getText().toString().trim();
        fy=etfy.getText().toString().trim();
        sy=etsy.getText().toString().trim();
        ty=etty.getText().toString().trim();

        button = findViewById(R.id.submit);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(Marks.this,Graph.class);
                startActivity(intent);
            }
        });
    }
}
