package com.android.swapnils.spa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;

public class Addsutd extends AppCompatActivity {
    ListView listView;
    ImageView iv_stud_det;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addsutd);
        listView=(ListView)findViewById(R.id.listview);
        iv_stud_det = findViewById(R.id.iv_stud_det_id);
        iv_stud_det.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Addsutd.this,studdetails.class);
                startActivity(i);
            }
        });

        ArrayList<String> arrayList=new ArrayList<>();
        arrayList.add("Pranoti");
        arrayList.add("Shruti");
        arrayList.add("Swapnil");
        arrayList.add("Sahil");
        arrayList.add("Siddhant");
        arrayList.add("Swaran");
        arrayList.add("Swarn");
        arrayList.add("Swara");
        arrayList.add("Shreyash");

        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrayList);
        listView.setAdapter(arrayAdapter);
    }
}
