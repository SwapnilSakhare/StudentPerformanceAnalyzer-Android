package com.android.swapnils.spa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class Dashboard extends AppCompatActivity {

    ImageButton addStud,marks,graph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        addStud=findViewById(R.id.add_student);
        addStud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Dashboard.this,Addsutd.class);
                startActivity(intent);

            }
        });

        marks=findViewById(R.id.marks_id);
        marks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Dashboard.this,Marks.class);
                startActivity(intent);
            }
        });

        graph=findViewById(R.id.graph_id);
        graph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Dashboard.this,Graph.class);
                startActivity(intent);
            }

        });
    }
}
