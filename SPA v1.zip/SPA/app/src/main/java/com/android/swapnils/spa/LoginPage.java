package com.android.swapnils.spa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class LoginPage extends AppCompatActivity {

    Button b2;
    String userId,password;
    EditText etusrname,etpswd;
    TextView Register;
    DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        etusrname = findViewById(R.id.usernameida);
        etpswd = findViewById(R.id.passwordida);
        Register=findViewById(R.id.toRegister);
        db=new DatabaseHandler(this);

        userId = etusrname.getText().toString().trim();
        password = etpswd.getText().toString().trim();

        b2 = findViewById(R.id.btnlogin);

        b2.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View v) {
                String userID = etusrname.getText().toString();
                String password = etpswd.getText().toString();
                boolean chknamepass=db.namepassword(userID,password);
                if (chknamepass==true){
                    Toast.makeText(getApplicationContext(),"Successfully Logged In",Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(LoginPage.this,Dashboard.class);
                    startActivity(intent);
                }else
                    Toast.makeText(getApplicationContext(),"Incorrect Username or Password",Toast.LENGTH_SHORT).show();
            }

        });
    }


//        b2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////             login();
//                Intent i = new Intent(LoginPage.this,Dashboard.class);
//                startActivity(i);
//            }
//        });
//
//        Register.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(LoginPage.this,RegistrationPage.class);
//                startActivity(intent);
//            }
//        });


//    private void login() {
//        if (userId.equals("Admin")&&password.equals("admin123")){
//            Intent i = new Intent(LoginPage.this,Dashboard.class);
//            startActivity(i);
//        }else{
//            Toast.makeText(LoginPage.this,"Incorrect Username Or Password.....!!!",Toast.LENGTH_SHORT).show();
//        }
//    }



}
