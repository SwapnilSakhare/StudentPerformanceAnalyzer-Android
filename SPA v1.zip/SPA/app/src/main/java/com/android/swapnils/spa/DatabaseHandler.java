package com.android.swapnils.spa;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {


    public DatabaseHandler( Context context) {
        super(context, "Login", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table user(username text,userID text,password text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if EXISTS user");

    }
    public boolean insert(String username,String userID,String password){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put( username,"username");
        contentValues.put( userID,"userID");
        contentValues.put(password,"password");
        long ins=db.insert(userID,null,contentValues);
        if(ins==-1)return false;
        else return true;
    }

    public boolean chkuserID(String userID) {
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from user where userID=?",new String[]{userID});
        if(cursor.getCount()>0)return false;
        else return true;
    }
    public boolean namepassword(String userID,String password){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from user where userID=? and password=?",new String[]{userID,password});
        if (cursor.getCount()>0) {
            return false;
        }
        else
            return true;
    }
}
