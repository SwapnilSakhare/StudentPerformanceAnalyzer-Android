package com.android.swapnils.spa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegistrationPage extends AppCompatActivity {
    Button button;
    String username,userId,password,reenterpassword;
    EditText etusrname,etusrId,etpswd,etrepswd;
    TextView toLog;
    DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);

        etusrname=findViewById(R.id.usernameid);
        etusrId=findViewById(R.id.userid);
        etpswd=findViewById(R.id.passwordid);
        etrepswd=findViewById(R.id.re_enterpassword);
        db=new DatabaseHandler(this);

        toLog = findViewById(R.id.toLogin);

        toLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(RegistrationPage.this,LoginPage.class);
                startActivity(i);
            }
        });

        button=findViewById(R.id.btnlogin);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                username=etusrname.getText().toString().trim();
                userId=etusrId.getText().toString().trim();
                password=etpswd.getText().toString().trim();
                reenterpassword=etrepswd.getText().toString().trim();

                if (username.equals("")||userId.equals("")||password.equals("")||reenterpassword.equals("")){
                    Toast.makeText(getApplicationContext(),"Field are empty",Toast.LENGTH_SHORT).show();
                }
                else{
                    if (password.equals(reenterpassword)){
                        boolean chkuserID=db.chkuserID(userId);
                        if (chkuserID==true);
                        boolean insert=db.insert(username,userId,password);
                        if (insert==true);{
                            Toast.makeText(getApplicationContext(),"Register successfully",Toast.LENGTH_SHORT).show();
                            Intent intent=new Intent(RegistrationPage.this,LoginPage.class);
                            startActivity(intent);
                        }

                    }
                    else {
                        Toast.makeText(getApplicationContext(),"userID Already exists",Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });
    }
   /* private void Registration(){
        Intent i = new Intent(RegistrationPage.this,LoginPage.class);
        startActivity(i);
    }*/
}
